import React from 'react';
import { Link } from 'react-router-dom';
import { Keyboard, Trophy, BookOpen, GamepadIcon, User } from 'lucide-react';
import { motion } from 'framer-motion';

const Navigation = () => {
  return (
    <nav className="bg-black/30 backdrop-blur-lg border-b border-white/10">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Keyboard className="w-8 h-8 text-purple-400" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
              TypeMaster
            </span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            <NavLink to="/practice" icon={<Keyboard />} text="Practice" />
            <NavLink to="/lessons" icon={<BookOpen />} text="Lessons" />
            <NavLink to="/challenges" icon={<GamepadIcon />} text="Challenges" />
            <NavLink to="/profile" icon={<User />} text="Profile" />
          </div>
        </div>
      </div>
    </nav>
  );
};

const NavLink = ({ to, icon, text }: { to: string; icon: React.ReactNode; text: string }) => (
  <Link
    to={to}
    className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors"
  >
    <motion.div
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      className="flex items-center space-x-2"
    >
      {icon}
      <span>{text}</span>
    </motion.div>
  </Link>
);

export default Navigation;