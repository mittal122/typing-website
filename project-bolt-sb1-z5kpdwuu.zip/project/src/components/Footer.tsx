import React from 'react';
import { Github, Twitter, Mail } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer = () => {
  return (
    <footer className="bg-black/30 backdrop-blur-lg border-t border-white/10 py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="text-gray-400 mb-4 md:mb-0">
            © 2024 TypeMaster. All rights reserved.
          </div>
          
          <div className="flex space-x-6">
            <SocialIcon href="#" icon={<Github />} />
            <SocialIcon href="#" icon={<Twitter />} />
            <SocialIcon href="#" icon={<Mail />} />
          </div>
        </div>
      </div>
    </footer>
  );
};

const SocialIcon = ({ href, icon }: { href: string; icon: React.ReactNode }) => (
  <motion.a
    href={href}
    className="text-gray-400 hover:text-purple-400 transition-colors"
    whileHover={{ scale: 1.2 }}
    whileTap={{ scale: 0.95 }}
  >
    {icon}
  </motion.a>
);

export default Footer;