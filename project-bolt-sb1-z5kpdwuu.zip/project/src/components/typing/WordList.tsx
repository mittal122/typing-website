import React from 'react';
import { motion } from 'framer-motion';

interface WordListProps {
  words: string[];
  currentWordIndex: number;
  userInput: string;
}

const WordList = ({ words, currentWordIndex, userInput }: WordListProps) => {
  return (
    <div className="flex flex-wrap gap-2 font-mono text-xl leading-relaxed">
      {words.map((word, wordIndex) => (
        <Word
          key={wordIndex}
          text={word}
          isCurrent={wordIndex === currentWordIndex}
          isCompleted={wordIndex < currentWordIndex}
          userInput={wordIndex === currentWordIndex ? userInput : ''}
        />
      ))}
    </div>
  );
};

const Word = ({ 
  text, 
  isCurrent, 
  isCompleted, 
  userInput 
}: { 
  text: string;
  isCurrent: boolean;
  isCompleted: boolean;
  userInput: string;
}) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className={`relative ${isCurrent ? 'text-white' : 'text-gray-500'} ${isCompleted ? 'text-green-400' : ''}`}
    >
      {text.split('').map((char, index) => {
        let charClass = '';
        if (isCurrent && index < userInput.length) {
          charClass = userInput[index] === char ? 'text-green-400' : 'text-red-400';
        }
        return (
          <span key={index} className={charClass}>
            {char}
          </span>
        );
      })}
      {isCurrent && (
        <motion.div
          className="absolute h-full w-0.5 bg-white"
          style={{ left: `${userInput.length}ch` }}
          animate={{ opacity: [1, 0] }}
          transition={{ repeat: Infinity, duration: 1 }}
        />
      )}
    </motion.div>
  );
};

export default WordList;