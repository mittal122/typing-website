import React from 'react';
import { motion } from 'framer-motion';
import { Activity, Target, AlertCircle } from 'lucide-react';

interface TypingStatsProps {
  wpm: number;
  accuracy: number;
  mistakes: number;
}

const TypingStats = ({ wpm, accuracy, mistakes }: TypingStatsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <StatCard
        icon={<Activity className="w-6 h-6 text-green-400" />}
        label="WPM"
        value={wpm}
      />
      <StatCard
        icon={<Target className="w-6 h-6 text-blue-400" />}
        label="Accuracy"
        value={accuracy}
        suffix="%"
      />
      <StatCard
        icon={<AlertCircle className="w-6 h-6 text-red-400" />}
        label="Mistakes"
        value={mistakes}
      />
    </div>
  );
};

const StatCard = ({ icon, label, value, suffix = '' }: {
  icon: React.ReactNode;
  label: string;
  value: number;
  suffix?: string;
}) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    className="p-4 bg-black/30 backdrop-blur-lg rounded-xl border border-white/10"
  >
    <div className="flex items-center space-x-3">
      {icon}
      <div>
        <p className="text-sm text-gray-400">{label}</p>
        <p className="text-2xl font-bold">{value}{suffix}</p>
      </div>
    </div>
  </motion.div>
);

export default TypingStats;