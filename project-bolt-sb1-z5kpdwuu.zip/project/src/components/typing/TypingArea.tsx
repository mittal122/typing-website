import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import WordList from './WordList';

interface TypingAreaProps {
  words: string[];
  currentWordIndex: number;
  userInput: string;
  onInputChange: (value: string) => void;
  isComplete: boolean;
}

const TypingArea = ({ 
  words, 
  currentWordIndex, 
  userInput, 
  onInputChange, 
  isComplete 
}: TypingAreaProps) => {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isComplete && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isComplete]);

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="space-y-8"
    >
      <div className="p-8 bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 min-h-[200px]">
        <WordList
          words={words}
          currentWordIndex={currentWordIndex}
          userInput={userInput}
        />
      </div>

      <input
        ref={inputRef}
        type="text"
        value={userInput}
        onChange={(e) => onInputChange(e.target.value)}
        disabled={isComplete}
        className="sr-only"
        autoFocus
      />
    </motion.div>
  );
};

export default TypingArea;