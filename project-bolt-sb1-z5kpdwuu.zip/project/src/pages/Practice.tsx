import React from 'react';
import { motion } from 'framer-motion';
import TypingArea from '../components/typing/TypingArea';
import TypingStats from '../components/typing/TypingStats';
import { useTyping } from '../hooks/useTyping';

const Practice = () => {
  const {
    words,
    currentWordIndex,
    userInput,
    accuracy,
    wpm,
    isComplete,
    mistakes,
    handleInputChange,
    resetPractice
  } = useTyping();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-4xl mx-auto space-y-8 py-12"
    >
      <TypingStats 
        wpm={wpm} 
        accuracy={accuracy} 
        mistakes={mistakes} 
      />

      <TypingArea
        words={words}
        currentWordIndex={currentWordIndex}
        userInput={userInput}
        onInputChange={handleInputChange}
        isComplete={isComplete}
      />

      {isComplete && (
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={resetPractice}
          className="mx-auto block px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full text-white font-semibold hover:shadow-lg transition-all duration-300"
        >
          Try Again
        </motion.button>
      )}
    </motion.div>
  );
};

export default Practice;