import React from 'react';
import { motion } from 'framer-motion';
import { Keyboard } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center text-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="space-y-8"
      >
        <motion.div
          animate={{ rotate: [0, 5, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="inline-block"
        >
          <Keyboard className="w-24 h-24 text-purple-400 mx-auto" />
        </motion.div>

        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-transparent bg-clip-text">
          Master Typing Skills Like a Pro!
        </h1>

        <p className="text-xl text-gray-300 max-w-2xl mx-auto">
          Enhance your typing speed and accuracy with our interactive lessons,
          real-time feedback, and engaging challenges.
        </p>

        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Link
            to="/practice"
            className="inline-block px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full text-white font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300"
          >
            Start Typing Now
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <FeatureCard
            title="Interactive Lessons"
            description="Learn with our structured curriculum designed for all skill levels"
          />
          <FeatureCard
            title="Real-time Feedback"
            description="Get instant feedback on your typing speed and accuracy"
          />
          <FeatureCard
            title="Fun Challenges"
            description="Compete with others and track your progress over time"
          />
        </div>
      </motion.div>
    </div>
  );
};

const FeatureCard = ({ title, description }: { title: string; description: string }) => (
  <motion.div
    whileHover={{ scale: 1.05 }}
    className="p-6 bg-white/5 backdrop-blur-lg rounded-xl border border-white/10"
  >
    <h3 className="text-xl font-semibold text-purple-400 mb-2">{title}</h3>
    <p className="text-gray-300">{description}</p>
  </motion.div>
);

export default Home;