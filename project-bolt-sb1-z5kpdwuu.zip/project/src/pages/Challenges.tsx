import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Users, Timer, Zap, Crown, Target } from 'lucide-react';

const challenges = [
  {
    id: 1,
    title: 'Speed Rush',
    description: 'Type as many words as you can in 60 seconds',
    players: 1243,
    difficulty: 'Medium',
    type: 'Time Trial',
    icon: <Timer className="w-6 h-6 text-yellow-400" />,
  },
  {
    id: 2,
    title: 'Accuracy Master',
    description: 'Complete the text with 100% accuracy',
    players: 856,
    difficulty: 'Hard',
    type: 'Precision',
    icon: <Target className="w-6 h-6 text-red-400" />,
  },
  {
    id: 3,
    title: 'Tournament',
    description: 'Compete against others in real-time',
    players: 2891,
    difficulty: 'Expert',
    type: 'Competitive',
    icon: <Crown className="w-6 h-6 text-purple-400" />,
  },
];

const Challenges = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-12"
      >
        <div className="space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
            Typing Challenges
          </h1>
          <p className="text-gray-400">Compete with others and test your skills</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((challenge) => (
            <ChallengeCard key={challenge.id} challenge={challenge} />
          ))}
        </div>

        <LeaderboardSection />
      </motion.div>
    </div>
  );
};

const ChallengeCard = ({ challenge }: { challenge: any }) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 overflow-hidden"
  >
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-3">
        {challenge.icon}
        <div>
          <h3 className="text-xl font-semibold text-white">{challenge.title}</h3>
          <span className="text-sm text-purple-400">{challenge.type}</span>
        </div>
      </div>
      
      <p className="text-gray-400">{challenge.description}</p>
      
      <div className="flex items-center justify-between text-sm text-gray-400">
        <span className="flex items-center gap-1">
          <Users className="w-4 h-4" />
          {challenge.players} players
        </span>
        <span className="px-3 py-1 bg-purple-500/20 rounded-full text-purple-400">
          {challenge.difficulty}
        </span>
      </div>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="w-full px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg text-white font-medium hover:shadow-lg transition-all duration-300"
      >
        Start Challenge
      </motion.button>
    </div>
  </motion.div>
);

const LeaderboardSection = () => (
  <div className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6">
    <h2 className="text-2xl font-bold mb-6">Global Leaderboard</h2>
    <div className="space-y-4">
      {[1, 2, 3].map((position) => (
        <motion.div
          key={position}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: position * 0.1 }}
          className="flex items-center justify-between p-4 bg-white/5 rounded-lg"
        >
          <div className="flex items-center gap-4">
            <span className="text-2xl font-bold text-purple-400">#{position}</span>
            <div>
              <h3 className="font-semibold">Player {position}</h3>
              <span className="text-sm text-gray-400">WPM: {120 - (position * 10)}</span>
            </div>
          </div>
          <Trophy className="w-6 h-6 text-yellow-400" />
        </motion.div>
      ))}
    </div>
  </div>
);

export default Challenges;