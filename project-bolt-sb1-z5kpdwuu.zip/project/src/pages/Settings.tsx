import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Volume2, Volume1, Monitor, Palette, Sliders } from 'lucide-react';

const Settings = () => {
  const [theme, setTheme] = useState('dark');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [volume, setVolume] = useState(80);

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
            Settings
          </h1>
          <p className="text-gray-400 mt-2">Customize your typing experience</p>
        </div>

        <div className="space-y-6">
          <SettingSection title="Appearance" icon={<Palette className="w-5 h-5" />}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <ThemeOption
                icon={<Sun />}
                title="Light"
                selected={theme === 'light'}
                onClick={() => setTheme('light')}
              />
              <ThemeOption
                icon={<Moon />}
                title="Dark"
                selected={theme === 'dark'}
                onClick={() => setTheme('dark')}
              />
              <ThemeOption
                icon={<Monitor />}
                title="System"
                selected={theme === 'system'}
                onClick={() => setTheme('system')}
              />
            </div>
          </SettingSection>

          <SettingSection title="Sound" icon={<Volume2 className="w-5 h-5" />}>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span>Enable Sound Effects</span>
                <Toggle enabled={soundEnabled} setEnabled={setSoundEnabled} />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Volume</span>
                  <span>{volume}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => setVolume(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-700 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-purple-500 [&::-webkit-slider-thumb]:rounded-full"
                />
              </div>
            </div>
          </SettingSection>

          <SettingSection title="Preferences" icon={<Sliders className="w-5 h-5" />}>
            <div className="space-y-4">
              <PreferenceOption
                title="Show WPM"
                description="Display words per minute while typing"
              />
              <PreferenceOption
                title="Show Accuracy"
                description="Display accuracy percentage while typing"
              />
              <PreferenceOption
                title="Show Timer"
                description="Display countdown timer during tests"
              />
            </div>
          </SettingSection>
        </div>
      </motion.div>
    </div>
  );
};

const SettingSection = ({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) => (
  <div className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6">
    <div className="flex items-center gap-2 mb-6">
      {icon}
      <h2 className="text-xl font-semibold">{title}</h2>
    </div>
    {children}
  </div>
);

const ThemeOption = ({ icon, title, selected, onClick }: { icon: React.ReactNode; title: string; selected: boolean; onClick: () => void }) => (
  <motion.button
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    className={`p-4 rounded-lg border ${
      selected ? 'border-purple-500 bg-purple-500/20' : 'border-white/10 bg-white/5'
    } flex items-center justify-center gap-2`}
  >
    {icon}
    <span>{title}</span>
  </motion.button>
);

const Toggle = ({ enabled, setEnabled }: { enabled: boolean; setEnabled: (enabled: boolean) => void }) => (
  <motion.button
    whileTap={{ scale: 0.95 }}
    onClick={() => setEnabled(!enabled)}
    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
      enabled ? 'bg-purple-500' : 'bg-gray-700'
    }`}
  >
    <span
      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
        enabled ? 'translate-x-6' : 'translate-x-1'
      }`}
    />
  </motion.button>
);

const PreferenceOption = ({ title, description }: { title: string; description: string }) => (
  <div className="flex items-center justify-between">
    <div>
      <h3 className="font-medium">{title}</h3>
      <p className="text-sm text-gray-400">{description}</p>
    </div>
    <Toggle enabled={true} setEnabled={() => {}} />
  </div>
);

export default Settings;