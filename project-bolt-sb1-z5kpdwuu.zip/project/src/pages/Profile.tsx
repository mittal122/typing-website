import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Target, Zap, Award, Clock, BarChart2 } from 'lucide-react';

const Profile = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div className="flex flex-col md:flex-row gap-8">
          <UserProfile />
          <Statistics />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Achievements />
          <RecentActivity />
        </div>
      </motion.div>
    </div>
  );
};

const UserProfile = () => (
  <div className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6 md:w-1/3">
    <div className="text-center space-y-4">
      <div className="w-24 h-24 mx-auto bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
        <span className="text-3xl font-bold">JD</span>
      </div>
      <div>
        <h2 className="text-2xl font-bold">John Doe</h2>
        <p className="text-gray-400">Typing Expert</p>
      </div>
      <div className="flex justify-center gap-4">
        <div className="text-center">
          <div className="text-xl font-bold">95</div>
          <div className="text-sm text-gray-400">WPM</div>
        </div>
        <div className="text-center">
          <div className="text-xl font-bold">98%</div>
          <div className="text-sm text-gray-400">Accuracy</div>
        </div>
      </div>
    </div>
  </div>
);

const Statistics = () => (
  <div className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6 flex-1">
    <h2 className="text-2xl font-bold mb-6">Statistics</h2>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <StatCard icon={<Zap className="w-6 h-6 text-yellow-400" />} title="Highest WPM" value="120" />
      <StatCard icon={<Target className="w-6 h-6 text-green-400" />} title="Average Accuracy" value="98%" />
      <StatCard icon={<Clock className="w-6 h-6 text-blue-400" />} title="Time Practiced" value="24h" />
    </div>
  </div>
);

const StatCard = ({ icon, title, value }: { icon: React.ReactNode; title: string; value: string }) => (
  <div className="bg-white/5 rounded-lg p-4">
    <div className="flex items-center gap-3 mb-2">
      {icon}
      <h3 className="font-semibold">{title}</h3>
    </div>
    <p className="text-2xl font-bold">{value}</p>
  </div>
);

const Achievements = () => (
  <div className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6">
    <h2 className="text-2xl font-bold mb-6">Achievements</h2>
    <div className="grid grid-cols-2 gap-4">
      <Achievement icon={<Trophy className="w-8 h-8 text-yellow-400" />} title="Speed Demon" description="Reach 100 WPM" />
      <Achievement icon={<Award className="w-8 h-8 text-purple-400" />} title="Perfect Score" description="100% Accuracy" />
    </div>
  </div>
);

const Achievement = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => (
  <motion.div
    whileHover={{ scale: 1.05 }}
    className="bg-white/5 rounded-lg p-4 flex items-center gap-4"
  >
    {icon}
    <div>
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-gray-400">{description}</p>
    </div>
  </motion.div>
);

const RecentActivity = () => (
  <div className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6">
    <h2 className="text-2xl font-bold mb-6">Recent Activity</h2>
    <div className="space-y-4">
      <ActivityItem
        icon={<BarChart2 className="w-5 h-5 text-green-400" />}
        title="New Personal Best"
        description="Reached 120 WPM"
        time="2h ago"
      />
      <ActivityItem
        icon={<Trophy className="w-5 h-5 text-yellow-400" />}
        title="Challenge Completed"
        description="Speed Rush Challenge"
        time="5h ago"
      />
    </div>
  </div>
);

const ActivityItem = ({ icon, title, description, time }: { icon: React.ReactNode; title: string; description: string; time: string }) => (
  <div className="flex items-center gap-4">
    <div className="p-2 bg-white/5 rounded-lg">{icon}</div>
    <div className="flex-1">
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-gray-400">{description}</p>
    </div>
    <span className="text-sm text-gray-400">{time}</span>
  </div>
);

export default Profile;