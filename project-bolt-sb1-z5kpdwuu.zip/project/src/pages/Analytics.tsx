import React from 'react';
import { motion } from 'framer-motion';
import { BarChart2, TrendingUp, Clock, Target, AlertCircle } from 'lucide-react';

const Analytics = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
            Analytics
          </h1>
          <p className="text-gray-400 mt-2">Track your typing performance and progress</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            icon={<TrendingUp className="w-6 h-6 text-green-400" />}
            title="Average WPM"
            value="85"
            trend="+5%"
          />
          <StatCard
            icon={<Target className="w-6 h-6 text-blue-400" />}
            title="Accuracy"
            value="98%"
            trend="+2%"
          />
          <StatCard
            icon={<Clock className="w-6 h-6 text-purple-400" />}
            title="Time Practiced"
            value="24h"
            trend="+3h"
          />
          <StatCard
            icon={<AlertCircle className="w-6 h-6 text-red-400" />}
            title="Error Rate"
            value="2%"
            trend="-1%"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <PerformanceChart />
          <ImprovementSuggestions />
        </div>
      </motion.div>
    </div>
  );
};

const StatCard = ({ icon, title, value, trend }: { icon: React.ReactNode; title: string; value: string; trend: string }) => (
  <motion.div
    whileHover={{ scale: 1.02 }}
    className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6"
  >
    <div className="flex items-center justify-between mb-4">
      <div className="p-2 bg-white/5 rounded-lg">
        {icon}
      </div>
      <span className={`text-sm ${trend.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
        {trend}
      </span>
    </div>
    <h3 className="text-gray-400">{title}</h3>
    <p className="text-2xl font-bold mt-1">{value}</p>
  </motion.div>
);

const PerformanceChart = () => (
  <div className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6">
    <div className="flex items-center justify-between mb-6">
      <h2 className="text-xl font-semibold">Performance Over Time</h2>
      <select className="bg-white/5 border border-white/10 rounded-lg px-3 py-1">
        <option>Last 7 Days</option>
        <option>Last 30 Days</option>
        <option>Last 3 Months</option>
      </select>
    </div>
    <div className="h-64 flex items-end justify-between gap-2">
      {[65, 70, 68, 75, 78, 80, 85].map((value, index) => (
        <motion.div
          key={index}
          initial={{ height: 0 }}
          animate={{ height: `${(value / 100) * 100}%` }}
          className="w-full bg-gradient-to-t from-purple-600 to-pink-600 rounded-t-lg"
        />
      ))}
    </div>
    <div className="flex justify-between mt-4 text-sm text-gray-400">
      <span>Mon</span>
      <span>Tue</span>
      <span>Wed</span>
      <span>Thu</span>
      <span>Fri</span>
      <span>Sat</span>
      <span>Sun</span>
    </div>
  </div>
);

const ImprovementSuggestions = () => (
  <div className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 p-6">
    <h2 className="text-xl font-semibold mb-6">Improvement Suggestions</h2>
    <div className="space-y-4">
      <Suggestion
        title="Practice Home Row"
        description="Focus on improving accuracy with home row keys"
        priority="High"
      />
      <Suggestion
        title="Speed Drills"
        description="Complete daily speed exercises to increase WPM"
        priority="Medium"
      />
      <Suggestion
        title="Touch Typing"
        description="Avoid looking at the keyboard while typing"
        priority="Low"
      />
    </div>
  </div>
);

const Suggestion = ({ title, description, priority }: { title: string; description: string; priority: string }) => (
  <motion.div
    whileHover={{ x: 5 }}
    className="flex items-start gap-4 p-4 bg-white/5 rounded-lg"
  >
    <div className="flex-1">
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-gray-400">{description}</p>
    </div>
    <span className={`px-2 py-1 rounded text-xs ${
      priority === 'High' ? 'bg-red-500/20 text-red-400' :
      priority === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' :
      'bg-green-500/20 text-green-400'
    }`}>
      {priority}
    </span>
  </motion.div>
);

export default Analytics;