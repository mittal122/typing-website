import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Star, Trophy } from 'lucide-react';

const lessons = [
  {
    id: 1,
    title: 'Home Row Mastery',
    level: 'Beginner',
    duration: '15 min',
    description: 'Master the home row keys (ASDF JKL;)',
    progress: 80,
  },
  {
    id: 2,
    title: 'Top Row Basics',
    level: 'Beginner',
    duration: '20 min',
    description: 'Learn the top row keys (QWERTY UIOP)',
    progress: 60,
  },
  {
    id: 3,
    title: 'Bottom Row Introduction',
    level: 'Intermediate',
    duration: '25 min',
    description: 'Practice bottom row keys (ZXCV BNM)',
    progress: 40,
  },
];

const Lessons = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
          Typing Lessons
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {lessons.map((lesson) => (
            <LessonCard key={lesson.id} lesson={lesson} />
          ))}
        </div>
      </motion.div>
    </div>
  );
};

const LessonCard = ({ lesson }: { lesson: any }) => (
  <motion.div
    whileHover={{ scale: 1.02, rotateY: 5 }}
    className="bg-black/30 backdrop-blur-lg rounded-xl border border-white/10 overflow-hidden"
  >
    <div className="p-6 space-y-4">
      <div className="flex justify-between items-start">
        <h3 className="text-xl font-semibold text-white">{lesson.title}</h3>
        <span className="px-3 py-1 bg-purple-500/20 rounded-full text-purple-400 text-sm">
          {lesson.level}
        </span>
      </div>
      
      <p className="text-gray-400">{lesson.description}</p>
      
      <div className="flex items-center justify-between text-sm text-gray-400">
        <span className="flex items-center gap-1">
          <BookOpen className="w-4 h-4" />
          {lesson.duration}
        </span>
        <span className="flex items-center gap-1">
          <Trophy className="w-4 h-4 text-yellow-400" />
          {lesson.progress}% Complete
        </span>
      </div>

      <div className="w-full bg-gray-700 rounded-full h-2">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${lesson.progress}%` }}
          className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full"
        />
      </div>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="w-full px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg text-white font-medium hover:shadow-lg transition-all duration-300"
      >
        Continue Lesson
      </motion.button>
    </div>
  </motion.div>
);

export default Lessons;