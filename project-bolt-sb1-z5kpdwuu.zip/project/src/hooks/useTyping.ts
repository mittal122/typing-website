import { useState, useCallback, useEffect } from 'react';
import { getRandomWords } from '../utils/textGenerator';

export const useTyping = () => {
  const [words, setWords] = useState(getRandomWords());
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [userInput, setUserInput] = useState('');
  const [startTime, setStartTime] = useState<number | null>(null);
  const [wpm, setWpm] = useState(0);
  const [accuracy, setAccuracy] = useState(100);
  const [mistakes, setMistakes] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  const calculateStats = useCallback(() => {
    if (!startTime) return;

    const timeElapsed = (Date.now() - startTime) / 1000 / 60; // in minutes
    const wordsTyped = currentWordIndex;
    const newWpm = Math.round(wordsTyped / timeElapsed);

    const totalChars = words.slice(0, currentWordIndex).join(' ').length;
    const correctChars = words
      .slice(0, currentWordIndex)
      .join(' ')
      .split('')
      .filter((char, i) => char === userInput[i])
      .length;
    
    const newAccuracy = Math.round((correctChars / totalChars) * 100) || 100;

    setWpm(newWpm);
    setAccuracy(newAccuracy);
  }, [startTime, currentWordIndex, words, userInput]);

  const handleInputChange = (value: string) => {
    if (!startTime) {
      setStartTime(Date.now());
    }

    if (value.endsWith(' ')) {
      if (value.trim() === words[currentWordIndex]) {
        setCurrentWordIndex(prev => prev + 1);
        setUserInput('');
        
        if (currentWordIndex === words.length - 1) {
          setIsComplete(true);
        }
      }
    } else {
      setUserInput(value);
    }
  };

  const resetPractice = () => {
    setWords(getRandomWords());
    setCurrentWordIndex(0);
    setUserInput('');
    setStartTime(null);
    setWpm(0);
    setAccuracy(100);
    setMistakes(0);
    setIsComplete(false);
  };

  useEffect(() => {
    if (!isComplete) {
      calculateStats();
    }
  }, [userInput, calculateStats, isComplete]);

  return {
    words,
    currentWordIndex,
    userInput,
    wpm,
    accuracy,
    mistakes,
    isComplete,
    handleInputChange,
    resetPractice,
  };
};